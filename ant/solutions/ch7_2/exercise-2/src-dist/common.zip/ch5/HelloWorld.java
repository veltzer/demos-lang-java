package ch5;

/**
 * @author ant
 *
 */
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Welcome from HelloWorld class");
	}
} 
